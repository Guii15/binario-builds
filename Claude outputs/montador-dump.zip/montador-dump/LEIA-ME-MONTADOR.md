# Dump — Montador de PC (Binário)

Projeto: site montador/configurador de PC usado pelos vendedores da Binário.
Repositório: `binario-builds` (React + TanStack Start).

Hoje as peças estão **fixas no código** (array `parts` em `src/routes/index.tsx`).
A ideia é o extrator puxar isso do WinThor e alimentar esse banco, igual foi
feito no catálogo (`catalogo.db`).

## Arquivos deste pacote

| Arquivo | O que é |
|---|---|
| `montador.db` | Banco SQLite com o schema + as 30 peças atuais (dados de exemplo/homologação) |
| `montador-dump.sql` | Mesmo conteúdo em SQL puro (schema + inserts) |
| `pecas-modelo.csv` | Formato-alvo do CSV que o extrator deve gerar (separador `;`) |

## Schema

### `categories` (12 linhas — fixas, não vêm do WinThor)

| Coluna | Tipo | Observação |
|---|---|---|
| `id` | TEXT PK | cpu, motherboard, memory, gpu, storage, psu, cooler, case, monitor, keyboard, mouse, chair |
| `label` | TEXT | Nome exibido na etapa |
| `short` | TEXT | Nome curto |
| `periferico` | INTEGER | 1 = não entra na compatibilidade nem trava a montagem |
| `multi` | INTEGER | 1 = pode escolher mais de uma peça/unidade |
| `ordem` | INTEGER | Ordem das etapas no site |

### `parts` (30 linhas hoje)

| Coluna | Tipo | Vem do WinThor? | Observação |
|---|---|---|---|
| `id` | TEXT PK | ❌ derivado | Slug único. **Usado no link compartilhado (`?pc=...`) — não pode mudar entre extrações**, senão orçamento antigo quebra |
| `category` | TEXT FK | ⚠️ classificar | Precisa mapear depto/seção do WinThor → categoria |
| `name` | TEXT | ✅ | `PCPRODUT.DESCRICAO` (tratada) |
| `brand` | TEXT | ✅ | Marca/fabricante |
| `code` | TEXT | ⚠️ | Hoje é o part number do fabricante. Se for usar `CODPROD` do WinThor, avisar — o site mostra esse código no orçamento |
| `pix_price` | REAL | ✅ | `PCTABPR.PVENDA` |
| `stock` | INTEGER | ✅ | Saldo disponível (`PCEST`). 0 = aparece como "sem estoque" |
| `platform` | TEXT | ❌ | `AMD` \| `Intel` — só cpu/motherboard |
| `socket` | TEXT | ❌ | `AM4` \| `AM5` \| `LGA1700` — **trava a compatibilidade CPU ↔ placa-mãe** |
| `mem_type` | TEXT | ❌ | `DDR4` \| `DDR5` — **trava a compatibilidade placa-mãe ↔ memória** |
| `watts` | INTEGER | ❌ | Consumo (cpu/gpu) ou capacidade (psu) — usado no cálculo da fonte |
| `ram_gb` | INTEGER | ❌ | Capacidade do pente/kit |
| `apu` | INTEGER | ❌ | 1 = processador com vídeo integrado (dispensa placa de vídeo) |
| `specs` | TEXT | ❌ | JSON array de strings — 3 bullets curtos no card |
| `detail` | TEXT | ❌ | Parágrafo descritivo do card |
| `foto` | TEXT | ⚠️ | Caminho `/fotos/<codigo>.jpg` |

## O ponto crítico pro extrator

O WinThor entrega bem: **descrição, marca, preço e estoque**.

O que o WinThor **não tem** e o site depende pra funcionar:

- `socket`, `mem_type`, `watts`, `ram_gb`, `apu`, `platform` — é o que faz a
  checagem de compatibilidade e o cálculo da fonte. Sem isso o montador deixa o
  vendedor fechar um PC que não monta.
- `specs` e `detail` — texto comercial dos cards.
- `category` — precisa de classificação (depto/seção + fallback por descrição,
  mesma abordagem que ficou decidida no catálogo).

Sugestão: o extrator traz preço/estoque/descrição do WinThor e essas colunas
técnicas ficam numa tabela de enriquecimento manual casada por `code`/`CODPROD`,
pra não serem sobrescritas a cada extração.

## Regra de ouro

`parts.id` é o identificador nos links de orçamento já enviados aos clientes.
Se a extração gerar id novo pro mesmo produto, os links antigos quebram.
