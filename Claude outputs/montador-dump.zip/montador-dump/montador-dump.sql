
-- Schema do catalogo de pecas do Montador de PC (Binario)
-- Gerado a partir de src/routes/index.tsx (array "parts")

CREATE TABLE categories (
  id         TEXT PRIMARY KEY,   -- cpu, motherboard, memory, gpu, storage, psu, cooler, case, monitor, keyboard, mouse, chair
  label      TEXT NOT NULL,      -- nome exibido na etapa
  short      TEXT NOT NULL,      -- nome curto (chips/resumo)
  periferico INTEGER NOT NULL,   -- 1 = nao entra na compatibilidade nem trava a montagem
  multi      INTEGER NOT NULL,   -- 1 = pode escolher mais de uma peca/unidade
  ordem      INTEGER NOT NULL    -- ordem das etapas no site
);

CREATE TABLE parts (
  id        TEXT PRIMARY KEY,    -- slug unico usado no link compartilhado (?pc=...) - NAO PODE MUDAR entre extracoes
  category  TEXT NOT NULL REFERENCES categories(id),
  name      TEXT NOT NULL,       -- WinThor: PCPRODUT.DESCRICAO (tratada)
  brand     TEXT NOT NULL,       -- WinThor: marca / fabricante
  code      TEXT NOT NULL,       -- codigo do fabricante (part number). Ver obs no LEIA-ME
  pix_price REAL NOT NULL,       -- WinThor: PCTABPR.PVENDA (preco no PIX)
  stock     INTEGER NOT NULL,    -- WinThor: PCEST saldo disponivel (0 = fora de estoque)
  platform  TEXT,                -- AMD | Intel      (so cpu/motherboard)
  socket    TEXT,                -- AM4 | AM5 | LGA1700  (so cpu/motherboard) - usado na COMPATIBILIDADE
  mem_type  TEXT,                -- DDR4 | DDR5      (motherboard/memory) - usado na COMPATIBILIDADE
  watts     INTEGER,             -- consumo (cpu/gpu) ou capacidade (psu) - usado no calculo da fonte
  ram_gb    INTEGER,             -- capacidade do pente/kit (so memory)
  apu       INTEGER,             -- 1 = processador com video integrado (dispensa placa de video)
  specs     TEXT,                -- JSON array de strings - 3 bullets curtos exibidos no card
  detail    TEXT,                -- paragrafo descritivo exibido no card
  foto      TEXT                 -- caminho da foto: /fotos/<codigo>.jpg
);

CREATE INDEX idx_parts_category ON parts(category);
CREATE INDEX idx_parts_socket   ON parts(socket);

INSERT INTO categories VALUES ('cpu', 'Processador', 'Processador', 0, 0, 1);
INSERT INTO categories VALUES ('motherboard', 'Placa-mãe', 'Placa-mãe', 0, 0, 2);
INSERT INTO categories VALUES ('memory', 'Memória RAM', 'Memória', 0, 1, 3);
INSERT INTO categories VALUES ('gpu', 'Placa de Vídeo', 'Vídeo', 0, 0, 4);
INSERT INTO categories VALUES ('storage', 'Armazenamento SSD', 'SSD NVMe', 0, 1, 5);
INSERT INTO categories VALUES ('psu', 'Fonte de Alimentação', 'Fonte', 0, 0, 6);
INSERT INTO categories VALUES ('cooler', 'Cooler / Water Cooler', 'Cooler', 0, 0, 7);
INSERT INTO categories VALUES ('case', 'Gabinete', 'Gabinete', 0, 0, 8);
INSERT INTO categories VALUES ('monitor', 'Monitor', 'Monitor', 1, 0, 9);
INSERT INTO categories VALUES ('keyboard', 'Teclado', 'Teclado', 1, 0, 10);
INSERT INTO categories VALUES ('mouse', 'Mouse', 'Mouse', 1, 0, 11);
INSERT INTO categories VALUES ('chair', 'Cadeira Gamer', 'Cadeira', 1, 0, 12);
INSERT INTO parts VALUES ('r5600', 'cpu', 'AMD Ryzen 5 5600G', 'AMD', '100-100000252BOX', 789.9, 8, 'AMD', 'AM4', NULL, 65, NULL, 1, '["6 Núcleos / 12 Threads","Vídeo Vega 7","Cooler Wraith Stealth"]', 'Ideal para PCs sem placa de vídeo dedicada inicial. Excelente desempenho em tarefas diárias e eSports leves.', '/fotos/cpu-intel.jpg');
INSERT INTO parts VALUES ('r7600', 'cpu', 'AMD Ryzen 5 7600', 'AMD', '100-100001015BOX', 1349.9, 4, 'AMD', 'AM5', NULL, 65, NULL, NULL, '["Plataforma AM5","DDR5 Native","Boost até 5.1 GHz"]', 'Nova geração de altíssimo desempenho em jogos competitivos e longevidade de plataforma.', '/fotos/cpu-intel.jpg');
INSERT INTO parts VALUES ('i514400', 'cpu', 'Intel Core i5-14400F', 'Intel', 'BX8071514400F', 1499.9, 5, 'Intel', 'LGA1700', NULL, 148, NULL, NULL, '["10 Núcleos / 16 Threads","Arquitetura Híbrida","Até 4.7 GHz"]', 'Excelente multitarefa, edição de vídeo e jogos de alta demanda de CPU.', '/fotos/cpu-intel.jpg');
INSERT INTO parts VALUES ('b550', 'motherboard', 'MSI B550M Pro-VDH WiFi', 'MSI', '911-7C95-021', 749.9, 4, 'AMD', 'AM4', 'DDR4', NULL, NULL, NULL, '["Socket AM4","Wi-Fi + Bluetooth","VRM Robusto com Dissipador"]', 'Placa completa com conexão sem fio e suporte total a overclock de memória DDR4.', '/fotos/placa-mae.jpg');
INSERT INTO parts VALUES ('b650', 'motherboard', 'ASRock B650M-HDV/M.2', 'ASRock', '90-MXBLA0-A0UAYZ', 899.9, 3, 'AMD', 'AM5', 'DDR5', NULL, NULL, NULL, '["Socket AM5","PCIe 4.0","Suporte DDR5 6000MHz+"]', 'Construção de alta durabilidade pronta para a linha Ryzen 7000 e upgrades futuros.', '/fotos/placa-mae.jpg');
INSERT INTO parts VALUES ('b760', 'motherboard', 'Gigabyte B760M DS3H DDR4', 'Gigabyte', 'B760M-DS3H-D4', 849.9, 6, 'Intel', 'LGA1700', 'DDR4', NULL, NULL, NULL, '["Socket LGA1700","Dual M.2 NVMe","Rede 2.5GbE"]', 'Estabilidade e conexão ultrarrápida para processadores Intel de 12ª, 13ª e 14ª geração.', '/fotos/placa-mae.jpg');
INSERT INTO parts VALUES ('ram16', 'memory', 'Kingston Fury Beast 16 GB (2x8GB)', 'Kingston', 'KF432C16BBK2-16', 329.9, 12, NULL, NULL, 'DDR4', NULL, 16, NULL, '["DDR4 3200MHz","Dual Channel","Dissipador de Alumínio"]', 'Configuração ideal para Dual Channel rápido e sem engasgos em jogos atuais.', '/fotos/ram-1.jpg');
INSERT INTO parts VALUES ('ram32', 'memory', 'Kingston Fury Beast 32 GB (2x16GB)', 'Kingston', 'KF556C36BBEK2-32', 729.9, 5, NULL, NULL, 'DDR5', NULL, 32, NULL, '["DDR5 5600MHz","AMD EXPO & XMP 3.0","Alta Densidade"]', 'Capacidade de sobra para jogos AAA pesados, multitarefa e renderização profissional.', '/fotos/ram-2.jpg');
INSERT INTO parts VALUES ('rx6600', 'gpu', 'ASRock Radeon RX 6600 Challenger D 8GB', 'ASRock', 'RX6600-CLD-8G', 1599.9, 4, NULL, NULL, NULL, 132, NULL, NULL, '["8 GB GDDR6","Cooler Dual Fan","O melhor custo-benefício Full HD"]', 'Roda todos os jogos modernos em 1080p com alta taxa de quadros e baixo consumo.', '/fotos/gpu.jpg');
INSERT INTO parts VALUES ('rtx4060', 'gpu', 'MSI GeForce RTX 4060 Ventus 2X Black 8GB', 'MSI', 'RTX4060-V2X-8G', 2199.9, 3, NULL, NULL, NULL, 115, NULL, NULL, '["8 GB GDDR6","NVIDIA DLSS 3 Frame Gen","Ray Tracing de 3ª Gen"]', 'Tecnologia DLSS 3 para dobrar sua taxa de quadros nos lançamentos mais recentes.', '/fotos/gpu.jpg');
INSERT INTO parts VALUES ('rtx4070', 'gpu', 'Galax GeForce RTX 4070 Super 12GB', 'Galax', '47SOM7MD9PSU', 4299.9, 2, NULL, NULL, NULL, 220, NULL, NULL, '["12 GB GDDR6X","Ideal para Quad HD (1440p)","Desempenho Extremo"]', 'Potência gráfica devastadora para jogar em resolução Quad HD no Ultra com Ray Tracing.', '/fotos/gpu.jpg');
INSERT INTO parts VALUES ('ssd1', 'storage', 'Kingston NV2 1 TB NVMe M.2', 'Kingston', 'SNV2S-1000G', 399.9, 18, NULL, NULL, NULL, NULL, NULL, NULL, '["Leitura até 3.500 MB/s","Gravação até 2.100 MB/s","PCIe 4.0 NVMe"]', 'Abertura instantânea de sistema operacional, programas e carregamento ultrarrápido de jogos.', '/fotos/ssd-nvme.jpg');
INSERT INTO parts VALUES ('ssd2', 'storage', 'WD Black SN770 2 TB NVMe M.2', 'WD Black', 'WDS200T3X0E', 899.9, 4, NULL, NULL, NULL, NULL, NULL, NULL, '["Leitura até 5.150 MB/s","Gamer Pro Grade","PCIe Gen4 x4"]', 'Desempenho e espaço massivo sem compromises para quem possui biblioteca gigante de jogos.', '/fotos/ssd-sata.jpg');
INSERT INTO parts VALUES ('psu550', 'psu', 'Cooler Master MWE Bronze V2 550 W', 'Cooler Master', 'MPE-5501-ACAAB', 389.9, 7, NULL, NULL, NULL, 550, NULL, NULL, '["80 Plus Bronze","PFC Ativo","Circuito DC-to-DC"]', 'Energia estável e segura para configurações intermediárias com placa de vídeo.', '/fotos/fonte.jpg');
INSERT INTO parts VALUES ('psu650', 'psu', 'Corsair CX650 650 W', 'Corsair', 'CP-9020278-BR', 529.9, 5, NULL, NULL, NULL, 650, NULL, NULL, '["80 Plus Bronze","5 Anos de Garantia Corsair","Ventoinha Silenciosa"]', 'Confiabilidade mundialmente reconhecida para sustentar placas como RTX 4060 e RX 7600.', '/fotos/fonte.jpg');
INSERT INTO parts VALUES ('psu750', 'psu', 'XPG Core Reactor II 750 W Gold', 'XPG', 'COREREACTORII750G', 749.9, 3, NULL, NULL, NULL, 750, NULL, NULL, '["80 Plus Gold / Cybenetics","Full Modular","Capacitores 100% Japoneses"]', 'Eficiência máxima de energia, cabeamento modular e garantia estendida de alto nível.', '/fotos/fonte.jpg');
INSERT INTO parts VALUES ('cool-hyper212', 'cooler', 'Cooler Master Hyper 212 Black', 'Cooler Master', 'RR-212S-20PK-R1', 219.9, 9, NULL, NULL, NULL, NULL, NULL, NULL, '["4 Heatpipes de contato direto","Ventoinha 120mm PWM","AM4 / AM5 / LGA1700"]', 'Troca o cooler de caixa e derruba a temperatura do processador em trabalho pesado.', NULL);
INSERT INTO parts VALUES ('cool-wc240', 'cooler', 'Water Cooler DeepCool LE520 240mm', 'DeepCool', 'R-LE520-BKAMNF-G-1', 479.9, 4, NULL, NULL, NULL, NULL, NULL, NULL, '["Radiador 240mm","Bomba de 3 anos de garantia","AM4 / AM5 / LGA1700"]', 'Refrigeração líquida para processadores mais quentes e gabinetes com vidro.', NULL);
INSERT INTO parts VALUES ('case-mid', 'case', 'Gabinete Gamer Redragon Wideload Mesh', 'Redragon', 'GC-608', 299.9, 7, NULL, NULL, NULL, NULL, NULL, NULL, '["Frontal em malha (mesh)","Lateral em vidro temperado","Suporta até 4 fans"]', 'Fluxo de ar bom e visual limpo para quem quer ver as peças por dentro.', '/fotos/gabinete.jpg');
INSERT INTO parts VALUES ('case-slim', 'case', 'Gabinete Slim K-Mex Micro-ATX', 'K-Mex', 'GM-05T8', 179.9, 11, NULL, NULL, NULL, NULL, NULL, NULL, '["Formato compacto","Micro-ATX","Ideal para balcão e recepção"]', 'Ocupa pouco espaço em mesa de escritório, caixa e recepção.', '/fotos/gabinete-azul.jpg');
INSERT INTO parts VALUES ('mon-24', 'monitor', 'Monitor AOC 24" 100Hz IPS Full HD', 'AOC', '24B2HM2', 749.9, 8, NULL, NULL, NULL, NULL, NULL, NULL, '["24 polegadas","1920x1080 @ 100Hz","Painel IPS"]', 'Tamanho mais vendido da loja. Serve tanto para trabalho quanto para jogo casual.', '/fotos/monitor.jpg');
INSERT INTO parts VALUES ('mon-27', 'monitor', 'Monitor Gamer LG UltraGear 27" 165Hz', 'LG', '27GS50F-B', 1349.9, 3, NULL, NULL, NULL, NULL, NULL, NULL, '["27 polegadas","1920x1080 @ 165Hz","1ms / AMD FreeSync"]', 'Taxa de atualização alta para jogos competitivos, sem rastro na imagem.', '/fotos/monitor.jpg');
INSERT INTO parts VALUES ('mon-office', 'monitor', 'Monitor Philips 22" Full HD', 'Philips', '221V8', 589.9, 12, NULL, NULL, NULL, NULL, NULL, NULL, '["22 polegadas","1920x1080 @ 75Hz","Modo de baixa luz azul"]', 'Opção econômica para planilha, sistema e emissão de nota.', '/fotos/monitor.jpg');
INSERT INTO parts VALUES ('kb-mec', 'keyboard', 'Teclado Mecânico Redragon Kumara ABNT2', 'Redragon', 'K552-ABNT2', 229.9, 10, NULL, NULL, NULL, NULL, NULL, NULL, '["Switch Outemu Blue","Layout ABNT2 com Ç","Iluminação RGB"]', 'Mecânico de entrada com o layout brasileiro certo, sem gambiarra de acento.', '/fotos/teclado-1.jpg');
INSERT INTO parts VALUES ('kb-office', 'keyboard', 'Teclado Multilaser Slim USB ABNT2', 'Multilaser', 'TC193', 59.9, 25, NULL, NULL, NULL, NULL, NULL, NULL, '["Membrana silenciosa","Layout ABNT2","Conexão USB"]', 'Simples e resistente para escritório, balcão e caixa.', '/fotos/teclado-2.jpg');
INSERT INTO parts VALUES ('kb-combo', 'keyboard', 'Combo Teclado + Mouse Sem Fio Logitech MK270', 'Logitech', '920-004433', 189.9, 6, NULL, NULL, NULL, NULL, NULL, NULL, '["Sem fio 2.4GHz","Receptor USB único","Pilhas inclusas"]', 'Deixa a mesa sem fio. Um receptor só atende teclado e mouse juntos.', '/fotos/teclado-2.jpg');
INSERT INTO parts VALUES ('mou-gamer', 'mouse', 'Mouse Gamer Logitech G203 Lightsync', 'Logitech', '910-005794', 159.9, 14, NULL, NULL, NULL, NULL, NULL, NULL, '["Até 8000 DPI","6 botões programáveis","RGB Lightsync"]', 'Leve e preciso, o mais pedido por quem joga FPS.', '/fotos/mouse.jpg');
INSERT INTO parts VALUES ('mou-office', 'mouse', 'Mouse Óptico Multilaser USB 1200 DPI', 'Multilaser', 'MO300', 34.9, 30, NULL, NULL, NULL, NULL, NULL, NULL, '["1200 DPI","3 botões","Cabo de 1,3m"]', 'Básico, barato e confiável para uso de escritório.', '/fotos/mouse.jpg');
INSERT INTO parts VALUES ('cad-gamer', 'chair', 'Cadeira Gamer ThunderX3 EC3 Reclinável', 'ThunderX3', 'EC3-BK', 1099.9, 3, NULL, NULL, NULL, NULL, NULL, NULL, '["Reclina até 180°","Apoio de braço 2D","Suporta até 120kg"]', 'Encosto alto e reclinável para quem passa o dia inteiro sentado.', NULL);
INSERT INTO parts VALUES ('cad-office', 'chair', 'Cadeira de Escritório Giratória com Encosto em Tela', 'Or Design', 'OR-3301', 549.9, 5, NULL, NULL, NULL, NULL, NULL, NULL, '["Encosto em tela respirável","Altura a gás","Base com 5 rodízios"]', 'Ventilada e mais discreta, pensada para escritório.', NULL);
